
Object.defineProperty(exports, "__esModule", { value: true });
exports.startContext = void 0;
// start the audio context
const tone_1 = __webpack_require__(/*! tone */ "tone");
function startContext() {
    tone_1.start();
}
exports.startContext = startContext;

